# Restaurant-Management-System
# Java_Swing
# Oracle DB
IDE used - Eclipse.
Database-Oracle.
This GUI Application is built using Java Swing, JDBC, and Oracle DB. The application has two major modules each consisting of its own modules. The application can be used to manage orders in a restaurant and Modify the menu of the Restaurant.

